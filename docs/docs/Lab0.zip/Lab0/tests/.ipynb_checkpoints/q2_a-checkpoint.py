OK_FORMAT = True

test = {   'name': 'q2_a',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> type(arr) == np.ndarray\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> arr[4] == 5\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
