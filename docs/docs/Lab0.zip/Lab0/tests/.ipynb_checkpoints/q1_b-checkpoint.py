OK_FORMAT = True

test = {   'name': 'q1_b',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(list_sum(a,b)) == list\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> list_sum([1], [1]) == [2]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> list1 = [1,2,3,4,5];\n>>> list2 = [2,4,6,8,10];\n>>> list_sum(list1, list1) == [2, 12, 36, 80, 150]\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
