OK_FORMAT = True

test = {   'name': 'q1_a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> n = 1;\n>>> type(summation(n)) == np.intc\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> summation(10) > 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> summation(1) == 6\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
