OK_FORMAT = True

test = {   'name': 'q0_b',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> fruit_info_mod1.loc[0, 'rank1'] == fruit_info_mod1.loc[0,'rank2']\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
