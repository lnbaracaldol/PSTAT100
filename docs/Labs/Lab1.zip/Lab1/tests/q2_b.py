OK_FORMAT = True

test = {   'name': 'q2_b',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> girl_name_count > boy_name_count\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
