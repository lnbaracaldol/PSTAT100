OK_FORMAT = True

test = {   'name': 'q1_b',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> num_years < 30 and num_years > 20\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> occur_per_year[2005] == 6874\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (occur_per_year[:1] == 6261).all()\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
