OK_FORMAT = True

test = {   'name': 'q0_c',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> fruit_info_original.shape == (4,2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> (fruit_info_original.columns == ['fruit', 'color']).all()\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
