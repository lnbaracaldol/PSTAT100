OK_FORMAT = True

test = {   'name': 'q2_a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> \n>>> int(names_95_max_count) == names_95_max_count\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(names_95_most_common_name.values[0]) == str\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
