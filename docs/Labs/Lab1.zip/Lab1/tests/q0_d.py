OK_FORMAT = True

test = {   'name': 'q0_d',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> fruit_info_mod2.shape == (4,2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> (fruit_info_mod2.columns == ['Fruit', 'Color']).all()\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
