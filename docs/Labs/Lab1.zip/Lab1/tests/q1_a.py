OK_FORMAT = True

test = {   'name': 'q1_a',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> dimensions_baby_names[1] == 5\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
